package com.heyumesh.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var speech: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private lateinit var output: TextView
    private lateinit var commandInput: EditText
    private val audio by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    companion object {
        @Volatile var latestNotification: String = "No notification received yet."
        private const val REQ_AUDIO = 41
        private const val REQ_CONTACTS = 42
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speech = TextToSpeech(this, this)
        buildScreen()
        requestRuntimePermissions()
    }

    private fun buildScreen() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFFF3F7FB.toInt())
        }
        val title = TextView(this).apply {
            text = "HEY UMESH"
            textSize = 30f
            setTextColor(0xFF102A43.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Your personal voice assistant"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 18)
        }
        output = TextView(this).apply {
            text = "Hi! Tap the microphone and say a command.\n\nTry: “Open YouTube”, “Call Arun”, “Volume up”, or “Read notifications”."
            textSize = 16f
            setTextColor(0xFF243B53.toInt())
            setPadding(16, 18, 16, 18)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        commandInput = EditText(this).apply { hint = "Type a command..." }
        val mic = makeButton("🎙  Speak to HEY UMESH") { listen() }
        val run = makeButton("Run typed command") { handleCommand(commandInput.text.toString()) }
        val controls = listOf(
            "Open YouTube" to { openApp("com.google.android.youtube", "YouTube") },
            "Open WhatsApp" to { openApp("com.whatsapp", "WhatsApp") },
            "Phone settings" to { startActivity(Intent(Settings.ACTION_SETTINGS)) },
            "Notification access" to { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
            "Brightness access" to { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).setData(android.net.Uri.parse("package:$packageName"))) }
        )
        outer.addView(title)
        outer.addView(subtitle)
        outer.addView(output, LinearLayout.LayoutParams(-1, 0, 1f))
        outer.addView(commandInput)
        outer.addView(mic)
        outer.addView(run)
        controls.forEach { (label, action) -> outer.addView(makeButton(label, action)) }
        val scroll = ScrollView(this).apply { addView(outer) }
        setContentView(scroll)
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun requestRuntimePermissions() {
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.RECORD_AUDIO)
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.READ_CONTACTS)
        if (needed.isNotEmpty()) requestPermissions(needed.toTypedArray(), REQ_AUDIO)
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Speech recognition is not available on this phone. You can type a command instead.")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_AUDIO)
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { show("Listening…") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { show("Processing…") }
            override fun onError(error: Int) { say("I couldn't hear that clearly. Please try again.") }
            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                commandInput.setText(spoken)
                handleCommand(spoken)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Say a command")
        }
        recognizer?.startListening(intent)
    }

    private fun handleCommand(raw: String) {
        val cmd = raw.trim().lowercase(Locale.getDefault())
        if (cmd.isBlank()) { say("Please say or type a command."); return }
        when {
            cmd.contains("open youtube") || cmd == "youtube" -> openApp("com.google.android.youtube", "YouTube")
            cmd.contains("open whatsapp") || cmd == "whatsapp" -> openApp("com.whatsapp", "WhatsApp")
            cmd.startsWith("open ") -> openNamedApp(raw.substringAfter("open ").trim())
            cmd.startsWith("call ") -> callContact(raw.substringAfter("call ").trim())
            cmd.contains("volume up") -> changeVolume(true)
            cmd.contains("volume down") -> changeVolume(false)
            cmd.contains("mute") -> { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0); say("Media volume muted.") }
            cmd.contains("unmute") -> { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0); say("Media volume restored.") }
            cmd.contains("brightness") -> adjustBrightness(cmd)
            cmd.contains("wifi") || cmd.contains("wi-fi") -> { startActivity(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)); say("Opening internet settings. Android requires you to confirm Wi-Fi changes.") }
            cmd.contains("bluetooth") -> { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); say("Opening Bluetooth settings.") }
            cmd.contains("read notifications") || cmd.contains("notifications") -> readNotifications()
            cmd.contains("home") -> { val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME); startActivity(i) }
            cmd.contains("time") -> say("The time is " + java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date()))
            cmd.contains("hello") || cmd.contains("hi") -> say("Hello! I'm HEY UMESH. What can I help you do?")
            cmd.contains("help") -> say("I can open apps, dial a contact, change media volume, adjust brightness when allowed, open Wi-Fi and Bluetooth settings, and read notifications after you grant access.")
            else -> {
                show("I don't have a matching phone action for: $raw\n\nFor general questions, use the web search option below.")
                say("I don't know that phone command yet. You can search the web for an answer.")
                val search = Button(this).apply {
                    text = "Search the web for this"
                    setOnClickListener {
                        val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, raw)
                        startActivity(i)
                    }
                }
                (output.parent as? LinearLayout)?.addView(search)
            }
        }
    }

    private fun openNamedApp(name: String) {
        val pm = packageManager
        val matches = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val target = matches.firstOrNull { it.loadLabel(pm).toString().equals(name, true) || it.loadLabel(pm).toString().contains(name, true) }
        if (target != null) {
            val launch = pm.getLaunchIntentForPackage(target.activityInfo.packageName)
            if (launch != null) { startActivity(launch); say("Opening ${target.loadLabel(pm)}."); return }
        }
        say("I couldn't find an installed app named $name.")
    }

    private fun openApp(pkg: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) { startActivity(launch); say("Opening $label.") }
        else say("$label is not installed.")
    }

    private fun callContact(name: String) {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), REQ_CONTACTS)
            say("Please grant contacts permission, then try again.")
            return
        }
        val cursor = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        )
        cursor?.use {
            if (it.moveToFirst()) {
                val number = it.getString(0)
                val contact = it.getString(1)
                // Uses the dialler, never places a call automatically.
                startActivity(Intent(Intent.ACTION_DIAL, android.net.Uri.parse("tel:$number")))
                say("Opening the dialler for $contact. Please confirm the call.")
                return
            }
        }
        say("I couldn't find a phone number for $name.")
    }

    private fun changeVolume(up: Boolean) {
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        say(if (up) "Volume increased." else "Volume decreased.")
    }

    private fun adjustBrightness(cmd: String) {
        if (!Settings.System.canWrite(this)) {
            say("Please grant brightness access from the Brightness access button first.")
            return
        }
        val current = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 120)
        val next = when {
            cmd.contains("up") || cmd.contains("increase") -> (current + 35).coerceAtMost(255)
            cmd.contains("down") || cmd.contains("decrease") -> (current - 35).coerceAtLeast(10)
            cmd.contains("max") -> 255
            cmd.contains("min") -> 10
            else -> current
        }
        Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, next)
        say("Brightness updated.")
    }

    private fun readNotifications() {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners").orEmpty()
        if (!enabled.contains(packageName)) {
            say("Please enable notification access using the Notification access button.")
        } else {
            say(latestNotification.ifBlank { "No notification has arrived since the app started." })
        }
    }

    private fun show(message: String) { runOnUiThread { output.text = message } }
    private fun say(message: String) {
        show(message)
        if (::speech.isInitialized) speech.speak(message, TextToSpeech.QUEUE_FLUSH, null, "hey_umesh_reply")
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) speech.language = Locale.getDefault()
    }
    override fun onDestroy() {
        recognizer?.destroy()
        if (::speech.isInitialized) speech.shutdown()
        super.onDestroy()
    }
}
