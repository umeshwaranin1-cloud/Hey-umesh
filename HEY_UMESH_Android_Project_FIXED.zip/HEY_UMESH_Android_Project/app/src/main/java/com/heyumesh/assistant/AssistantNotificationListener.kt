package com.heyumesh.assistant

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class AssistantNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        // Notifications are not uploaded or stored. Reading is performed only in-app
        // after the user grants Android's Notification Access permission.
        MainActivity.latestNotification = "${sbn.packageName}: ${sbn.notification.extras.getCharSequence("android.title") ?: ""}. ${sbn.notification.extras.getCharSequence("android.text") ?: ""}"
    }
}
