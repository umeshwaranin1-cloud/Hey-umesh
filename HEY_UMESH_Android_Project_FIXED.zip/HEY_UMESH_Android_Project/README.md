# HEY UMESH — Android starter app

This is a native Kotlin Android project for a Vivo V30e / Android phone.

## Included in this first build
- Tap-to-talk speech recognition using Android's installed speech service.
- Spoken replies using Android Text-to-Speech.
- Launch YouTube, WhatsApp, and other installed apps by their displayed names.
- Find a contact and open the phone dialler (the user confirms the call).
- Media volume up/down/mute.
- Brightness adjustment after the user grants Android's special write-settings access.
- Opens Android internet/Wi-Fi and Bluetooth settings; Android retains confirmation/control.
- Reads the latest notification text after the user explicitly grants Notification Access.
- No feature deletes files, photos, videos, contacts, messages, or other personal data.

## Important limitations
- This is a source project, not a compiled or signed APK.
- Wake phrase detection ("Hey Umesh") is NOT active in the background in this version. Android background microphone rules and device-vendor restrictions make true always-on custom wake-word listening a separate, device-tested feature.
- General AI chat is not connected to a private AI model/API. Unknown questions offer Android web search. A secure AI backend/API must be configured separately; never put a secret API key in the APK.
- Android 16 may require device-specific permission and behavior testing. Target SDK is set to 35 for broad compatibility; it should be updated and tested against API 36 before release.
- Some Vivo/Funtouch OS power-management settings may stop background services; this version avoids claiming an always-running listener.

## Build
Open this folder in Android Studio on a computer, or use a compatible Android IDE/build environment that supports Gradle, Kotlin, Android SDK 36, and JDK 17.
Run a Gradle sync, then Build > Build APK(s). The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## First launch
1. Grant microphone permission to use voice input.
2. Grant contacts permission only if you want voice contact lookup.
3. Tap Notification access and enable HEY UMESH if you want notification reading.
4. Tap Brightness access and allow modify system settings if you want brightness commands.
5. Test each action manually.

## Safety
- Calls open the dialler and do not auto-call.
- Wi-Fi/Bluetooth commands open Android settings rather than bypassing OS controls.
- No destructive data operations are implemented.
